#pragma once

PHP_FUNCTION(thrift_protocol_write_binary);
PHP_FUNCTION(thrift_protocol_read_binary);

extern zend_module_entry thrift_protocole_module_entry;

