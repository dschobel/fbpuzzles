#pragma once

PHP_FUNCTION(thrift_protocol_binary_deserialize);

extern zend_module_entry thrift_protocole_module_entry;

