#import "TProtocolException.h"

@implementation TProtocolException
@end
