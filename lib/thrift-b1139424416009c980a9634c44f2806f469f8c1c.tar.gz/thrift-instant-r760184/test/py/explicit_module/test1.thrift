namespace py foo.bar.baz

struct astruct {
  1: i32 how_unoriginal;
}
